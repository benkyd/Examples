# Warning

The certificates in this folder are for testing and should never be used to
register your devices.
